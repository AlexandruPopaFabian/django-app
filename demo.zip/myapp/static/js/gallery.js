const slides = document.querySelectorAll(".slides img");
let slideindex = 0;
let intervalID = null;

document.addEventListener("DOMContentLoaded", initializeSlider);

function initializeSlider() {
    if (slides.length > 0) {
        slides[slideindex].classList.add("displaySlide");
        intervalID = setInterval(nextSlide, 3000); 
    }
}

function showSlide(index) {   
    if (index >= slides.length) {
        slideindex = 0;
    } else if (index < 0) {
        slideindex = slides.length - 1;
    } else {
        slideindex = index;
    }

    slides.forEach(slide =>{
        slide.classList.remove("displaySlide");});
    slides[slideindex].classList.add("displaySlide");
}

function prevSlide() {   
    clearInterval(intervalID);
    slideindex--;
    showSlide(slideindex);
    restartAutoSlide();
}

function nextSlide() {
    clearInterval(intervalID);
    slideindex++;
    showSlide(slideindex);
    restartAutoSlide();
}

function restartAutoSlide() {
    clearInterval(intervalID);
    intervalID = setInterval(nextSlide, 3000);
}
